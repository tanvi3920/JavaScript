let x=prompt("enter size");
let a=new Array();
for(var i=0;i<x;i++)
{
	a[i]=prompt("enter");
}
let b=new Array();
b=a.reverse();
for( i=0;i<x;i++)
{
	console.log(b[i]);
}

