let x=prompt("Enter the no of minutes");
console.log("no of seconds are" + x*60);